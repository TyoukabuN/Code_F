﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Singleton<T> where T :Singleton<T>,new() {

    public readonly static T Instance = new T();
}
