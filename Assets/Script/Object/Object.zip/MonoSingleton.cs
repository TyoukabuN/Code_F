﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public abstract class MonoSingleton<T> : MonoBehaviour where T : MonoSingleton<T>, new()
{

    private static T _instance = null;
    public static T Instance
    {
        get
        {
            if (_instance == null) {
                _instance = FindObjectOfType<T>() ?? new GameObject(typeof(T).Name).AddComponent<T>();
                _instance.transform.hideFlags = HideFlags.NotEditable;
            }
            return _instance;
        }
    }
    private void Awake()
    {
        _instance = _instance ?? this as T;
        if (this!=_instance)
        {
            Destroy(this);
        }
    }
}
